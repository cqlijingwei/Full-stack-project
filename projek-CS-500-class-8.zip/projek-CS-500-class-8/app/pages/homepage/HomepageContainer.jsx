import React, { Component } from 'react'
import HomePageBody from './HomePageBody'

export default class HomePageContainer extends Component {

	render() {
		return (
			<div>
				<HomePageBody/>
			</div>
		)
	}
}