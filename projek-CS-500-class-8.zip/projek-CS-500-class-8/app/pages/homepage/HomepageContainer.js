import React, { Component } from 'react'

export default class HomePageContainer extends Component {

	render() {
		return (
			<div>
			hello
			</div>
		)
	}
}