export const umsAPI = {
	signup: 'users/signup',
	signin: 'users/signin',
	signout: 'users/signout',
	getProfile: 'users',
}