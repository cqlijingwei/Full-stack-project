# website for projek
The frontend project for projek, a platform for companies to place projects so that freelancers can come and choose a project that they want to work on. The platform charges a transaction fee.

Dev Setup steps:

1. run `npm start`

2. visit localhost:3000