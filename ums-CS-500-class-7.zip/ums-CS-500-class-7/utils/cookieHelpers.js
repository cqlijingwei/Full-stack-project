export const USER_ID_COOKIE = 'pj_uid'
export const EMAIL_COOKIE = 'pj_e'
export const SESSION_ID_COOKIE = 'pj_ssid'
