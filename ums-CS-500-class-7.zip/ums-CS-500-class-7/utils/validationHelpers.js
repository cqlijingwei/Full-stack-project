export let isEmptyArray = (array) => {
	return !array || !array.length
}