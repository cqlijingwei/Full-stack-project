export const meeAppConfig = {
	baseUrl: '',
}

export const env = 'prod'