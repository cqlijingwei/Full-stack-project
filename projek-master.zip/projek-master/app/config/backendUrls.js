export const MeeAppURL = {
	signup: '',
}